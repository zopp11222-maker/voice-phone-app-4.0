package com.voicephone

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** ภาพพิกเซลแบบ Minecraft วาดด้วยโค้ด ไม่ต้องใช้ไฟล์รูป */
object Pixel {
    val MIC = listOf(
        "....oooo....",
        "...oaaabo...",
        "...oaaabo...",
        "...occcco...",
        "...oaaabo...",
        "...occcco...",
        "...oaaabo...",
        "...obbbbo...",
        "...oooooo...",
        ".ob......bo.",
        ".ob......bo.",
        ".oob....boo.",
        "..ooobbooo..",
        "....obbo....",
        "....obbo....",
        "..oooooooo..",
    )
    val PHONE = listOf(
        ".oooooo.",
        "obbbbbbo",
        "obaaaabo",
        "obaaaabo",
        "obaaaabo",
        "obaaaabo",
        "obaaaabo",
        "obaaaabo",
        "obbbbbbo",
        "obbooobo",
        "obbbbbbo",
        ".oooooo.",
    )

    private val DARK = Color.parseColor("#0B1220")
    private fun mic(a: String, b: String, c: String) = mapOf(
        'o' to DARK, 'a' to Color.parseColor(a), 'b' to Color.parseColor(b), 'c' to Color.parseColor(c))

    val MIC_ON = mic("#8CFF9B", "#43C75A", "#2A8F3E")
    val MIC_OFF = mic("#FF9A90", "#E5483B", "#A12A20")
    val MIC_IDLE = mic("#EAF3FF", "#9DB9E0", "#6F8FBF")
    val PHONE_PAL = mapOf('o' to DARK, 'b' to Color.parseColor("#3A6FB5"), 'a' to Color.parseColor("#9AD1FF"))
}

class PixelView(ctx: Context, private val grid: List<String>) : View(ctx) {
    var palette: Map<Char, Int> = emptyMap()
        set(v) { field = v; invalidate() }
    private val paint = Paint()

    override fun onDraw(c: Canvas) {
        val rows = grid.size
        val cols = grid[0].length
        val s = maxOf(1, minOf(width / cols, height / rows))
        val ox = (width - s * cols) / 2
        val oy = (height - s * rows) / 2
        for (y in 0 until rows) for (x in 0 until cols) {
            val col = palette[grid[y][x]] ?: continue
            paint.color = col
            c.drawRect((ox + x * s).toFloat(), (oy + y * s).toFloat(),
                (ox + (x + 1) * s).toFloat(), (oy + (y + 1) * s).toFloat(), paint)
        }
    }
}

/** โหลดรูปโปรไฟล์ Xbox จากชื่อผู้เล่น (ถ้าโหลดไม่ได้จะใช้ตัวอักษรย่อแทน) */
object Avatars {
    private val cache = ConcurrentHashMap<String, Bitmap>()
    private val failed = ConcurrentHashMap<String, Long>()
    private val loading = ConcurrentHashMap<String, Boolean>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun get(name: String): Bitmap? = cache[name.lowercase()]

    fun load(name: String, done: () -> Unit) {
        val k = name.lowercase()
        if (cache.containsKey(k)) return
        val t = failed[k]
        if (t != null && System.currentTimeMillis() - t < 60000) return
        if (loading.putIfAbsent(k, true) != null) return
        pool.execute {
            try {
                val tag = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
                val c = URL("https://avatar-ssl.xboxlive.com/avatar/$tag/avatarpic-l.png")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000
                val bmp = if (c.responseCode == 200) BitmapFactory.decodeStream(c.inputStream) else null
                if (bmp != null) { cache[k] = bmp; main.post { done() } }
                else failed[k] = System.currentTimeMillis()
            } catch (e: Exception) {
                failed[k] = System.currentTimeMillis()
            } finally {
                loading.remove(k)
            }
        }
    }
}

class AvatarView(ctx: Context) : FrameLayout(ctx) {
    private val letter = TextView(ctx).apply {
        gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 18f
    }
    private val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = GONE }

    init {
        addView(letter, LayoutParams(-1, -1))
        addView(img, LayoutParams(-1, -1))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        clipToOutline = true
    }

    fun bind(name: String) {
        val hue = (Math.abs(name.hashCode()) % 360).toFloat()
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.HSVToColor(floatArrayOf(hue, 0.5f, 0.75f)))
        }
        letter.text = name.take(1).uppercase()
        val b = Avatars.get(name)
        if (b != null) { img.setImageBitmap(b); img.visibility = VISIBLE }
        else { img.visibility = GONE; Avatars.load(name) { bind(name) } }
    }
}
