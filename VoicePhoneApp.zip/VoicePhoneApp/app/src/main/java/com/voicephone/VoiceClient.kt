package com.voicephone

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.SystemClock
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** ไคลเอนต์เสียง: จับไมค์ -> ส่งขึ้นเซิร์ฟเวอร์/รีเลย์, รับเสียงคนอื่น -> เล่นออกลำโพง/หูฟัง */
class VoiceClient(
    private val url: String,
    private val name: String,
    private val failHint: String,
    private val onStatus: (Status) -> Unit,
    private val onClosed: (String) -> Unit,
) {
    data class PlayerInfo(val name: String, val muted: Boolean, val call: String)
    data class Status(
        val mc: Boolean, val game: Boolean, val muted: Boolean,
        val range: Int, val call: String, val players: List<PlayerInfo>,
    )

    private class Speaker(val track: AudioTrack) {
        var primed = false
        var queued = 0
        var last = 0L
    }

    companion object { const val SR = 16000 }

    @Volatile var muted = true
    @Volatile var level = 0f
    @Volatile private var running = false
    @Volatile private var opened = false
    @Volatile private var lastError = ""
    private var http: OkHttpClient? = null
    private var ws: WebSocket? = null
    private val speakers = HashMap<Int, Speaker>()
    private val playExec = Executors.newSingleThreadExecutor()

    fun start() {
        running = true
        // timeout สั้นพอให้รู้ว่าต่อไม่ติด แต่ readTimeout ยาวพอให้รีเลย์ฟรีที่หลับอยู่ตื่นทัน
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(75, TimeUnit.SECONDS)
            .pingInterval(15, TimeUnit.SECONDS)
            .build()
        http = client
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                opened = true
                VoiceService.addLog("เชื่อมเซิร์ฟเวอร์เสียงสำเร็จ")
                webSocket.send(JSONObject().put("t", "join").put("name", name).toString())
                startMic()
            }
            override fun onMessage(webSocket: WebSocket, text: String) { handleText(text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handleAudio(bytes.toByteArray()) }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                VoiceService.addLog("ปิดการเชื่อมต่อ code=$code $reason")
                end()
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                lastError = t.message ?: ""
                VoiceService.addLog("client error: ${t.javaClass.simpleName} ${t.message}")
                end()
            }
        })
    }

    private fun end() {
        val unexpected = running
        running = false
        releaseAudio()
        try { http?.dispatcher?.executorService?.shutdown() } catch (e: Exception) { }
        if (unexpected) onClosed(
            if (!opened) failHint
            else if (lastError.isNotEmpty()) "สัญญาณขาดหาย ($lastError)" else "สัญญาณขาดหาย")
    }

    fun stop() {
        running = false
        try { ws?.close(1000, "bye") } catch (e: Exception) { }
        releaseAudio()
        try { http?.dispatcher?.executorService?.shutdown() } catch (e: Exception) { }
    }

    fun toggleMute() {
        val want = if (muted) 0 else 1
        muted = want == 1
        try { ws?.send(JSONObject().put("t", "mute").put("m", want).toString()) } catch (e: Exception) { }
    }

    private fun handleText(s: String) {
        val j = try { JSONObject(s) } catch (e: Exception) { return }
        if (j.optString("t") != "status") return
        val arr = j.optJSONArray("players")
        val list = ArrayList<PlayerInfo>()
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(PlayerInfo(o.optString("name"), o.optBoolean("muted"), o.optString("call")))
        }
        muted = j.optBoolean("muted", true)
        onStatus(Status(j.optBoolean("mc"), j.optBoolean("game"), muted,
            j.optInt("range"), j.optString("call"), list))
    }

    // ---------- ไมค์ ----------
    @SuppressLint("MissingPermission")
    private fun startMic() {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192))
        thread(name = "vc-mic") {
            val buf = ShortArray(1024)
            var gateUntil = 0L
            try {
                rec.startRecording()
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 1) continue
                    var sum = 0.0
                    for (i in 0 until n) { val v = buf[i] / 32768.0; sum += v * v }
                    val rms = sqrt(sum / n)
                    level = min(1f, (rms * 5).toFloat())
                    val now = SystemClock.elapsedRealtime()
                    if (rms > 0.012) gateUntil = now + 400
                    val w = ws
                    if (muted || now > gateUntil || w == null || !opened) continue
                    val enc = Codec.encode(buf, n)
                    w.send(enc.toByteString(0, enc.size))
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
            }
        }
    }

    // ---------- เล่นเสียงคนอื่น ----------
    private fun newTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(min, SR))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun handleAudio(arr: ByteArray) {
        if (arr.size <= 2) return
        val id = arr[0].toInt() and 0xFF
        val gain = (arr[1].toInt() and 0xFF) / 255f
        val pcm = Codec.decode(arr, 2, arr.size - 2)
        try {
            playExec.execute {
                try {
                    val sp = speakers.getOrPut(id) { Speaker(newTrack()) }
                    val now = SystemClock.elapsedRealtime()
                    if (sp.primed && now - sp.last > 300) {   // เงียบนาน -> เตรียมบัฟเฟอร์ใหม่
                        sp.track.pause(); sp.track.flush(); sp.primed = false; sp.queued = 0
                    }
                    sp.track.setVolume(gain)
                    val n = sp.track.write(pcm, 0, pcm.size, AudioTrack.WRITE_NON_BLOCKING)
                    if (n > 0) sp.queued += n
                    if (!sp.primed && sp.queued >= 1600) { sp.track.play(); sp.primed = true }
                    sp.last = now
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    private fun releaseAudio() {
        try {
            playExec.execute {
                for (sp in speakers.values) { try { sp.track.stop(); sp.track.release() } catch (e: Exception) { } }
                speakers.clear()
            }
            playExec.shutdown()
        } catch (e: Exception) { }
    }
}
