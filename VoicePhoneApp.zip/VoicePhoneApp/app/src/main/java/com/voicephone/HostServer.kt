package com.voicephone

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocketListener
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * พอร์ตจาก vc.js: รับสถานะจาก Minecraft (พอร์ต 19131, เฉพาะในเครื่อง)
 * และเป็นเซิร์ฟเวอร์รีเลย์เสียง (พอร์ต 8080) ให้ทุกคน
 */
class HostServer(private val relayUrl: String?, private val log: (String) -> Unit) {
    class Player(var name: String) {
        @Volatile var range = 30
        @Volatile var muted = false
        @Volatile var call = ""
        @Volatile var pos: DoubleArray? = null
        @Volatile var dim = 0
        @Volatile var seen = System.currentTimeMillis()
        /** ความดังที่ผู้เล่นคนนี้ตั้งไว้ให้เสียงของคนอื่น (ชื่อพิมพ์เล็ก -> เปอร์เซ็นต์ 1-200) */
        @Volatile var vols: Map<String, Int> = emptyMap()
    }

    private class Client(val id: Int) { @Volatile var name: String? = null }

    private val players = ConcurrentHashMap<String, Player>()
    private val pending = ConcurrentHashMap<String, String>()
    private val clients = ConcurrentHashMap<WebSocket, Client>()
    private val nextId = AtomicInteger(0)
    private val scheduler = Executors.newScheduledThreadPool(1)
    @Volatile private var mc: WebSocket? = null
    private var mcServer: WebSocketServer? = null
    private var voiceServer: WebSocketServer? = null

    @Volatile private var relayWs: okhttp3.WebSocket? = null
    @Volatile private var relayUp = false
    @Volatile private var relayErr = ""
    @Volatile private var stopped = false
    private var http: OkHttpClient? = null

    @Volatile private var mcUp = false
    @Volatile private var voiceUp = false
    @Volatile private var mcErr = ""
    @Volatile private var voiceErr = ""

    /** สรุปสถานะทีละข้อ ให้หน้าแอปแสดงว่าติดตรงไหน */
    fun diag(): List<String> {
        val first = if (relayUrl != null)
            (if (relayUp) "✅ เชื่อมรีเลย์แล้ว เพื่อนต่อเข้าห้องได้เลย"
             else "⏳ กำลังเชื่อมรีเลย์… (ครั้งแรกอาจนานราว 1 นาที) $relayErr")
        else
            (if (voiceUp) "✅ เซิร์ฟเวอร์เสียง (พอร์ต 8080) พร้อมรับเพื่อน" else "❌ เซิร์ฟเวอร์เสียงเปิดไม่ได้ $voiceErr")
        val lines = mutableListOf(
            first,
            if (mcUp) "✅ ช่องรอ Minecraft (พอร์ต 19131) พร้อม" else "❌ ช่องรอ Minecraft เปิดไม่ได้ $mcErr",
            if (mc?.isOpen == true) "✅ Minecraft เชื่อมกับแอปแล้ว" else "⏳ Minecraft ยังไม่เชื่อม — เข้าโลกแล้วพิมพ์ /wsserver 127.0.0.1:19131",
        )
        if (relayUrl == null) lines.add("👥 คนที่ต่อเสียงเข้ามาตอนนี้: ${clients.values.count { it.name != null }} (รวมตัวคุณ)")
        return lines
    }

    private val msgRe = Regex("""VC\|(\d+)\|([01])\|([^|]*)(?:\|(.*))?$""")
    private val lastVoice = ConcurrentHashMap<String, Long>()   // ชื่อพิมพ์เล็ก -> เวลาที่ได้ยินเสียงล่าสุด
    private var lastTalkSent = ""

    private fun parseVols(s: String): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (part in s.split(',')) {
            val i = part.lastIndexOf(':')
            if (i <= 0) continue
            val v = part.substring(i + 1).trim().toIntOrNull() ?: continue
            out[part.substring(0, i).trim().lowercase()] = v.coerceIn(1, 200)
        }
        return out
    }

    /** บอกเกมว่าใครกำลังพูด เพื่อให้ขึ้นไอคอนลำโพงเหนือหัว */
    private fun pushTalk() {
        val now = System.currentTimeMillis()
        val names = lastVoice.entries.filter { now - it.value < 600 }
            .mapNotNull { players[it.key]?.name }.sorted()
        val key = names.joinToString("|")
        if (key.isEmpty() && lastTalkSent.isEmpty()) return
        lastTalkSent = key
        if (key.isNotEmpty()) mcSend("scriptevent vc:talk $key")
    }

    fun start() {
        try {
            mcServer = McServer().also { it.isReuseAddr = true; it.connectionLostTimeout = 0; it.start() }
        } catch (e: Throwable) { log("เปิดพอร์ต 19131 ไม่ได้: ${e.message}") }
        if (relayUrl == null) {
            try {
                voiceServer = VoiceServer().also { it.isReuseAddr = true; it.isTcpNoDelay = true; it.connectionLostTimeout = 10; it.start() }
            } catch (e: Throwable) { log("เปิดพอร์ต 8080 ไม่ได้: ${e.message}") }
        } else {
            connectRelay()
            scheduler.scheduleWithFixedDelay({
                try { pushToRelay() } catch (e: Exception) { }
            }, 500, 500, TimeUnit.MILLISECONDS)
        }
        scheduler.scheduleWithFixedDelay({
            try { queryPlayers() } catch (e: Exception) { }
        }, 500, 500, TimeUnit.MILLISECONDS)
        scheduler.scheduleWithFixedDelay({
            try { broadcastStatus() } catch (e: Exception) { }
        }, 1000, 1000, TimeUnit.MILLISECONDS)
        scheduler.scheduleWithFixedDelay({
            try { pushTalk() } catch (e: Exception) { }
        }, 300, 300, TimeUnit.MILLISECONDS)
    }

    // ---------- โหมดออนไลน์: โฮสต์ส่งข้อมูลผู้เล่นไปให้รีเลย์ ----------
    private fun connectRelay() {
        if (stopped || relayUrl == null) return
        val c = http ?: OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS).readTimeout(75, TimeUnit.SECONDS)
            .pingInterval(15, TimeUnit.SECONDS).build().also { http = it }
        relayWs = c.newWebSocket(Request.Builder().url(relayUrl).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: okhttp3.WebSocket, response: Response) {
                relayUp = true; relayErr = ""
                webSocket.send(JSONObject().put("t", "host").toString())
                log("เชื่อมรีเลย์สำเร็จ (โฮสต์)")
            }
            override fun onMessage(webSocket: okhttp3.WebSocket, text: String) { handleRelay(text) }
            override fun onClosing(webSocket: okhttp3.WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: okhttp3.WebSocket, code: Int, reason: String) {
                relayUp = false; log("รีเลย์ตัดการเชื่อมต่อ ($code $reason)"); retryRelay()
            }
            override fun onFailure(webSocket: okhttp3.WebSocket, t: Throwable, response: Response?) {
                relayUp = false; relayErr = t.message ?: ""
                log("รีเลย์ error: ${t.javaClass.simpleName} ${t.message}"); retryRelay()
            }
        })
    }

    private fun retryRelay() {
        if (stopped) return
        try { scheduler.schedule({ connectRelay() }, 3, TimeUnit.SECONDS) } catch (e: Exception) { }
    }

    private fun handleRelay(raw: String) {
        val j = try { JSONObject(raw) } catch (e: Exception) { return }
        if (j.optString("t") == "talk") {
            val arr = j.optJSONArray("names") ?: return
            val now = System.currentTimeMillis()
            for (i in 0 until arr.length()) lastVoice[arr.optString(i).lowercase()] = now
            return
        }
        if (j.optString("t") != "cmd") return
        val p = players[j.optString("name").lowercase()] ?: return
        val m = if (j.optInt("m") == 1) 1 else 0
        p.muted = m == 1
        mcSend("scriptevent vc:mute $m|${p.name}")
    }

    private fun pushToRelay() {
        val w = relayWs ?: return
        if (!relayUp) return
        val arr = JSONArray()
        for (p in players.values) {
            if (!fresh(p)) continue
            val o = JSONObject().put("name", p.name).put("range", p.range)
                .put("muted", p.muted).put("call", p.call).put("dim", p.dim)
            val vo = JSONObject()
            for ((k, v) in p.vols) vo.put(k, v)
            o.put("vols", vo)
            val pos = p.pos
            if (pos != null) o.put("x", pos[0]).put("y", pos[1]).put("z", pos[2])
            arr.put(o)
        }
        w.send(JSONObject().put("t", "players").put("mc", mc?.isOpen == true).put("list", arr).toString())
    }

    fun stop() {
        stopped = true
        try { relayWs?.close(1000, "bye") } catch (e: Exception) { }
        try { http?.dispatcher?.executorService?.shutdown() } catch (e: Exception) { }
        scheduler.shutdownNow()
        try { mcServer?.stop(300) } catch (e: Exception) { }
        try { voiceServer?.stop(300) } catch (e: Exception) { }
    }

    // ---------- ส่งคำสั่งเข้า Minecraft ----------
    private fun mcSend(cmd: String): String? {
        val c = mc ?: return null
        if (!c.isOpen) return null
        val id = UUID.randomUUID().toString()
        val msg = JSONObject()
            .put("header", JSONObject().put("version", 1).put("requestId", id)
                .put("messagePurpose", "commandRequest").put("messageType", "commandRequest"))
            .put("body", JSONObject().put("version", 1).put("commandLine", cmd)
                .put("origin", JSONObject().put("type", "player")))
        c.send(msg.toString())
        return id
    }

    private fun queryPlayers() {
        for ((key, p) in players) {
            val id = mcSend("querytarget @a[name=\"${p.name}\"]")
            if (id != null) pending[id] = key
        }
        if (pending.size > 500) pending.clear()
    }

    private fun num(text: String, k: String): Double? =
        Regex("""\\?"$k\\?"\s*:\s*(-?[\d.]+)""").find(text)?.groupValues?.get(1)?.toDoubleOrNull()

    private fun handleMc(raw: String) {
        val j = try { JSONObject(raw) } catch (e: Exception) { return }
        val h = j.optJSONObject("header") ?: JSONObject()
        val b = j.optJSONObject("body") ?: JSONObject()

        if (h.optString("messagePurpose") == "commandResponse") {
            val key = pending.remove(h.optString("requestId")) ?: return
            val p = players[key] ?: return
            val text = b.optString("details") + b.optString("statusMessage")
            val x = num(text, "x"); val y = num(text, "y"); val z = num(text, "z")
            val d = num(text, "dimension")
            if (x == null || z == null) { p.pos = null; return }
            p.pos = doubleArrayOf(x, y ?: 0.0, z)
            p.dim = d?.toInt() ?: 0
            p.seen = System.currentTimeMillis()
            return
        }

        if (h.optString("eventName") == "PlayerMessage" || b.has("message")) {
            val msg = b.optString("message").replace(Regex("§."), "")
            val m = msgRe.find(msg)
            val sender = b.optString("sender")
            if (m != null && sender.isNotEmpty()) {
                val p = players.getOrPut(sender.lowercase()) { Player(sender) }
                p.name = sender
                p.range = m.groupValues[1].toIntOrNull() ?: 30
                p.muted = m.groupValues[2] == "1"
                p.call = m.groupValues[3].trim()
                p.vols = parseVols(m.groupValues.getOrElse(4) { "" })
                p.seen = System.currentTimeMillis()
            }
        }
    }

    private fun fresh(p: Player) = System.currentTimeMillis() - p.seen < 15000

    private fun gainFor(s: Player, l: Player): Double {
        val sc = s.call.lowercase(); val lc = l.call.lowercase()
        val mult = (l.vols[s.name.lowercase()] ?: 100) / 100.0
        if (sc.isNotEmpty() && lc.isNotEmpty() && sc == l.name.lowercase() && lc == s.name.lowercase()) return 1.0 * mult
        val sp = s.pos; val lp = l.pos
        if (sp == null || lp == null || s.dim != l.dim) return 0.0
        val dx = sp[0] - lp[0]; val dy = sp[1] - lp[1]; val dz = sp[2] - lp[2]
        val d = sqrt(dx * dx + dy * dy + dz * dz)
        val r = s.range.toDouble()
        if (d > r) return 0.0
        val near = r * 0.4
        val base = if (d <= near) 1.0 else max(0.0, 1 - (d - near) / (r - near))
        return base * mult
    }

    private fun playerList(): JSONArray {
        val list = JSONArray()
        for (p in players.values) {
            if (!fresh(p)) continue
            list.put(JSONObject().put("name", p.name).put("range", p.range)
                .put("muted", p.muted).put("call", p.call))
        }
        return list
    }

    private fun sendStatus(ws: WebSocket, c: Client, list: JSONArray) {
        val n = c.name
        if (!ws.isOpen || n == null) return
        val p = players[n.lowercase()]?.takeIf { fresh(it) }
        val o = JSONObject().put("t", "status").put("v", 2).put("mc", mc?.isOpen == true).put("game", p != null)
            .put("range", p?.range ?: 0).put("muted", p?.muted ?: true)
            .put("call", p?.call ?: "").put("players", list)
        ws.send(o.toString())
    }

    private fun broadcastStatus() {
        val list = playerList()
        for ((ws, c) in clients) sendStatus(ws, c, list)
    }

    // ---------- เซิร์ฟเวอร์ที่ Minecraft มาเชื่อม (/wsserver) ----------
    private inner class McServer : WebSocketServer(InetSocketAddress("127.0.0.1", 19131)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake?) {
            mc = conn
            log("Minecraft เชื่อมต่อแล้ว")
            conn.send(JSONObject()
                .put("header", JSONObject().put("version", 1).put("requestId", UUID.randomUUID().toString())
                    .put("messagePurpose", "subscribe").put("messageType", "commandRequest"))
                .put("body", JSONObject().put("eventName", "PlayerMessage")).toString())
            mcSend("scriptevent vc:sync")
        }
        override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
            if (mc === conn) mc = null
            log("Minecraft ตัดการเชื่อมต่อ")
        }
        override fun onMessage(conn: WebSocket, message: String?) { if (message != null) handleMc(message) }
        override fun onError(conn: WebSocket?, ex: Exception?) {
            log("MC error: ${ex?.javaClass?.simpleName} ${ex?.message}")
            if (conn == null) { mcUp = false; mcErr = ex?.message ?: "" }
        }
        override fun onStart() { mcUp = true; log("พร้อมรอ Minecraft ที่ 127.0.0.1:19131") }
    }

    // ---------- เซิร์ฟเวอร์เสียงที่แอปทุกคนเชื่อม ----------
    private inner class VoiceServer : WebSocketServer(InetSocketAddress(8080)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake?) {
            clients[conn] = Client(nextId.getAndIncrement() % 250)
            log("มีไคลเอนต์เสียงเชื่อมเข้ามา")
        }
        override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
            clients.remove(conn)
        }
        override fun onError(conn: WebSocket?, ex: Exception?) {
            log("Voice error: ${ex?.javaClass?.simpleName} ${ex?.message}")
            if (conn == null) { voiceUp = false; voiceErr = ex?.message ?: "" }
        }
        override fun onStart() { voiceUp = true; log("เซิร์ฟเวอร์เสียงพร้อมที่พอร์ต 8080") }

        override fun onMessage(conn: WebSocket, message: String?) {
            val c = clients[conn] ?: return
            val j = try { JSONObject(message ?: return) } catch (e: Exception) { return }
            when (j.optString("t")) {
                "join" -> {
                    c.name = j.optString("name").trim().take(32)
                    log("เข้าร่วมเสียง: ${c.name}")
                    sendStatus(conn, c, playerList())     // ส่งสถานะทันที ไม่ต้องรอรอบถัดไป
                    mcSend("scriptevent vc:sync")
                }
                "mute" -> {
                    val n = c.name ?: return
                    val p = players[n.lowercase()] ?: return
                    val m = if (j.optInt("m") == 1) 1 else 0
                    p.muted = m == 1
                    mcSend("scriptevent vc:mute $m|${p.name}")
                }
            }
        }

        override fun onMessage(conn: WebSocket, message: ByteBuffer?) {
            if (message == null) return
            val c = clients[conn] ?: return
            val name = c.name ?: return
            val s = players[name.lowercase()] ?: return
            if (s.muted || !fresh(s)) return
            lastVoice[name.lowercase()] = System.currentTimeMillis()
            val data = ByteArray(message.remaining()); message.get(data)
            for ((w2, c2) in clients) {
                if (w2 === conn || !w2.isOpen) continue
                val n2 = c2.name ?: continue
                val l = players[n2.lowercase()] ?: continue
                val g = gainFor(s, l)
                if (g < 0.02) continue
                val out = ByteArray(2 + data.size)
                out[0] = c.id.toByte()
                out[1] = (g * 127.5).roundToInt().coerceAtMost(255).toByte()
                System.arraycopy(data, 0, out, 2, data.size)
                w2.send(out)
            }
        }
    }
}
