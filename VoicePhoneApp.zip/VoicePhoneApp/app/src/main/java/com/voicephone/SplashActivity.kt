package com.voicephone

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** หน้าปกแอป */
class SplashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0E2F6B")
        window.navigationBarColor = Color.parseColor("#0A1628")
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0E2F6B"), Color.parseColor("#0A1628")))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; alpha = 0f }
        col.addView(PixelView(this, Pixel.MIC).apply { palette = Pixel.MIC_IDLE }, LinearLayout.LayoutParams(px(72), px(96)))
        col.addView(TextView(this).apply {
            text = getString(R.string.app_name); textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(10) })
        col.addView(TextView(this).apply {
            text = "แชทเสียงใน Minecraft PE"; textSize = 14f; setTextColor(Color.parseColor("#9DB4D6"))
            gravity = Gravity.CENTER
        })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        root.addView(TextView(this).apply {
            text = ver; textSize = 12f; setTextColor(Color.parseColor("#6F8FBF"))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = px(14) })

        setContentView(root)
        col.animate().alpha(1f).setDuration(700).start()
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1700)
    }
}
