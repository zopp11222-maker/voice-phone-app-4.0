package com.voicephone

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // ธีมน้ำเงิน
    private val BG = Color.parseColor("#0A1628")
    private val PANEL = Color.parseColor("#11284A")
    private val PANEL2 = Color.parseColor("#1B3B6F")
    private val LINE = Color.parseColor("#2A4A80")
    private val ACCENT = Color.parseColor("#2F7BFF")
    private val TEXT2 = Color.parseColor("#9DB4D6")
    private val RED = Color.parseColor("#E53935")
    private val GREEN = Color.parseColor("#43A047")
    private val AMBER = Color.parseColor("#FFB300")

    private lateinit var profileAvatar: AvatarView
    private lateinit var profileName: TextView
    private lateinit var profileStatus: TextView
    private lateinit var dot: View
    private lateinit var connectBtn: Button
    private lateinit var listTitle: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var micPixel: PixelView
    private lateinit var micLabel: TextView
    private lateinit var meter: ProgressBar
    private lateinit var addrLabel: TextView
    private lateinit var diagLabel: TextView
    private var addrAt = 0L
    private lateinit var micToggle: Button
    private var lastSig = "?"
    private var lastName = "?"

    private val COMMANDS = listOf(
        "/wsserver 127.0.0.1:19131" to "เชื่อมเกมกับแอป (โฮสต์พิมพ์คนเดียว)",
        "/give @s vc:phone" to "รับไอเทมโทรศัพท์",
        "/scriptevent vc:sync" to "ซิงค์สถานะอีกครั้ง",
    )

    private val APP_NOTES = """
        • ตัดเสียงรบกวนไมค์ (ตั้งค่า > ตัดเสียงรบกวน: ปิด/ปกติ/แรง) ส่งเฉพาะตอนเราพูดจริง
        • ฝังรีเลย์กลางไว้ในแอปแล้ว: เพื่อนแค่ใส่ "รหัสห้อง" สั้นๆ ไม่ต้องตั้งรีเลย์เอง
        • โหมดออนไลน์: เน็ตมือถือกับ WiFi คุยกันได้ ไม่ต้องอยู่เครือข่ายเดียวกัน
        • โฮสต์ตั้งรหัสห้องเองได้ (จำง่าย) แล้วแตะป้ายคัดลอกส่งเพื่อน
        • ย่อขนาดเสียงลง 4 เท่า ประหยัดเน็ตมือถือ
    """.trimIndent()
    private val MOD_NOTES = """
        • v1.10: แก้แป้นกดเบอร์ไม่ให้ปิดทันทีตอนกดเลข + โหมดดีบัก /scriptevent vc:debug
        • v1.8: แก้แป้นกดเบอร์ให้แสดงปุ่ม 1-9, 0, *, # ครบทุกปุ่ม
        • v1.7: แป้นกดเบอร์แบบโทรศัพท์ หน้าสายเรียกเข้าแบบใหม่ ปุ่มทุกปุ่มมี texture ของตัวเอง
        • v1.6: คำสั่ง vc:mute ซิงค์ไมค์กับแอป
    """.trimIndent()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, r: Int = 12, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) this.shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
        setColor(color)
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun btn(t: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 13f; stateListAnimator = null
        background = shape(color, 10); minHeight = 0; minimumHeight = 0; setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { onClick() }
    }
    private fun input(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine()
        setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        background = shape(PANEL, 8); setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    private fun divider() = View(this).apply { setBackgroundColor(LINE) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        prefs = getSharedPreferences("vc", MODE_PRIVATE)
        VoiceService.noiseLevel = prefs.getInt("noise", 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(BG) }
        root.addView(buildLeft(), LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(dp(2), -1))
        root.addView(buildRight(), LinearLayout.LayoutParams(0, -1, 1.7f))
        setContentView(root)

        val ver = versionName()
        if (prefs.getString("seen_version", "") != ver) {
            showUpdates()
            prefs.edit().putString("seen_version", ver).apply()
        }
    }

    // ---------- ฝั่งซ้าย: โปรไฟล์ / รายชื่อผู้เล่น / ตั้งค่า+ไมค์ ----------
    private fun buildLeft(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(PANEL) }

        val prof = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        profileAvatar = AvatarView(this)
        row.addView(profileAvatar, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        profileName = tv("", 16f, Color.WHITE, true).apply { setSingleLine() }
        val srow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dot = View(this)
        srow.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(6) })
        profileStatus = tv("", 11f, TEXT2).apply { setSingleLine() }
        srow.addView(profileStatus)
        info.addView(profileName)
        info.addView(srow)
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        prof.addView(row)
        connectBtn = btn("เชื่อมต่อเสียง", ACCENT) { onConnectClick() }
        prof.addView(connectBtn, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(8) })
        col.addView(prof)
        col.addView(divider(), LinearLayout.LayoutParams(-1, dp(2)))

        listTitle = tv("👥 ผู้เล่นในเซิร์ฟเวอร์", 13f, TEXT2, true).apply { setPadding(dp(12), dp(8), dp(12), dp(4)) }
        col.addView(listTitle)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), dp(8)) }
        col.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(divider(), LinearLayout.LayoutParams(-1, dp(2)))

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        bottom.addView(btn("⚙ ตั้งค่า", PANEL2) { showSettings() },
            LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(6) })
        micToggle = btn("🎤 ไมค์", RED) { toggleMic() }
        bottom.addView(micToggle, LinearLayout.LayoutParams(0, dp(40), 1f))
        col.addView(bottom)
        return col
    }

    // ---------- ฝั่งขวา: รูปไมค์ / คำสั่ง / ปุ่มโทรศัพท์ดูอัปเดต ----------
    private fun buildRight(): View {
        val frame = FrameLayout(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(60))
        }
        micPixel = PixelView(this, Pixel.MIC).apply {
            palette = Pixel.MIC_OFF
            setOnClickListener { toggleMic() }
        }
        col.addView(micPixel, LinearLayout.LayoutParams(dp(96), dp(128)))
        micLabel = tv("", 15f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        col.addView(micLabel, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(GREEN)
        }
        col.addView(meter, LinearLayout.LayoutParams(dp(180), dp(6)).apply { topMargin = dp(4) })
        addrLabel = tv("", 11f, AMBER).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                val share = inviteShare()
                if (prefs.getBoolean("online", false) && prefs.getBoolean("host", true) && share != null) {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("room", share))
                    toast("คัดลอกแล้ว: $share ส่งให้เพื่อนได้เลย")
                }
            }
        }
        col.addView(addrLabel, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        diagLabel = tv("", 11f, TEXT2)
        col.addView(diagLabel, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })

        col.addView(tv("⌨ คำสั่ง (แตะเพื่อคัดลอก)", 14f, TEXT2, true),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        for ((cmd, desc) in COMMANDS) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = shape(PANEL, 8)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("cmd", cmd))
                    toast("คัดลอกแล้ว: $cmd")
                }
            }
            card.addView(tv(cmd, 13f, Color.WHITE).apply { typeface = Typeface.MONOSPACE })
            card.addView(tv(desc, 10f, TEXT2))
            col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        frame.addView(ScrollView(this).apply { isFillViewport = true; addView(col, FrameLayout.LayoutParams(-1, -2)) },
            FrameLayout.LayoutParams(-1, -1))

        val phone = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = shape(PANEL2, 12); setPadding(dp(10), dp(6), dp(10), dp(4))
            setOnClickListener { showUpdates() }
        }
        phone.addView(PixelView(this, Pixel.PHONE).apply { palette = Pixel.PHONE_PAL },
            LinearLayout.LayoutParams(dp(26), dp(39)))
        phone.addView(tv("อัปเดต", 10f, TEXT2))
        frame.addView(phone, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(14), dp(12)) })
        return frame
    }

    // ---------- ปุ่ม/หน้าต่างต่างๆ ----------
    private fun onConnectClick() {
        if (VoiceService.running) {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            return
        }
        val name = prefs.getString("name", "").orEmpty().trim()
        if (name.isEmpty()) { toast("ตั้งชื่อในเกมก่อน"); showSettings(); return }
        val online = prefs.getBoolean("online", false)
        val host = prefs.getBoolean("host", true)
        if (online) {
            if (host && prefs.getString("room", "").orEmpty().isEmpty())
                prefs.edit().putString("room", RelayLink.randomRoom()).apply()
            if (onlineTarget() == null) {
                toast(if (host) "รหัสห้องไม่ถูกต้อง ตั้งใหม่ในตั้งค่า" else "ใส่รหัสห้องที่โฮสต์ส่งให้ในตั้งค่าก่อน")
                showSettings(); return
            }
        } else if (!host && prefs.getString("server", "").orEmpty().isEmpty()) {
            toast("ใส่ IP:พอร์ตของโฮสต์ในตั้งค่าก่อน"); showSettings(); return
        }
        ensurePermsThenStart()
    }

    private fun toggleMic() {
        if (VoiceService.running && VoiceService.connected)
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_TOGGLE))
        else toast("เชื่อมต่อเสียงก่อน")
    }

    private fun showSettings() {
        val running = VoiceService.running
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val nameIn = input("ชื่อในเกม (พิมพ์ให้ตรงเป๊ะ)", prefs.getString("name", "").orEmpty())
        val hostSw = Switch(this).apply {
            text = "เป็นโฮสต์ (รันเซิร์ฟเวอร์ในเครื่องนี้)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("host", true)
        }
        val onlineSw = Switch(this).apply {
            text = "ออนไลน์ (ต่างเครือข่าย/เน็ตมือถือก็เล่นด้วยกันได้)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("online", false)
        }
        val serverIn = input("IP:พอร์ต ของโฮสต์ เช่น 192.168.43.1:8080", prefs.getString("server", "").orEmpty())
        val roomIn = input("รหัสห้องของคุณ (a-z 0-9 _ - ยาว 4-32 ตัว)",
            prefs.getString("room", "").orEmpty().ifEmpty { RelayLink.randomRoom() })
        val joinIn = input("รหัสห้อง (หรือลิงก์ห้อง) ที่โฮสต์ส่งให้", prefs.getString("join", "").orEmpty())
        val relayIn = input("(ขั้นสูง) ที่อยู่รีเลย์ ปล่อยว่าง = ใช้ของแอป", prefs.getString("relay", "").orEmpty())
        val info = tv("", 12f, TEXT2)
        fun upd() {
            val on = onlineSw.isChecked
            val h = hostSw.isChecked
            serverIn.visibility = if (!on && !h) View.VISIBLE else View.GONE
            roomIn.visibility = if (on && h) View.VISIBLE else View.GONE
            joinIn.visibility = if (on && !h) View.VISIBLE else View.GONE
            relayIn.visibility = if (on) View.VISIBLE else View.GONE
            info.text = when {
                on && h -> "ส่งรหัสห้องนี้ให้เพื่อน เพื่อนแค่ใส่รหัสในแอป (ใช้รีเลย์กลางของแอปให้อัตโนมัติ)"
                on -> "ใส่รหัสห้องที่โฮสต์ส่งให้ ไม่ต้องใส่อย่างอื่น"
                h -> ipInfo()
                else -> "ใส่ที่อยู่ของเครื่องโฮสต์ เช่น 192.168.43.1:8080"
            }
        }
        hostSw.setOnCheckedChangeListener { _, _ -> upd() }
        onlineSw.setOnCheckedChangeListener { _, _ -> upd() }
        upd()
        if (running) { nameIn.isEnabled = false; hostSw.isEnabled = false; onlineSw.isEnabled = false
            serverIn.isEnabled = false; relayIn.isEnabled = false; roomIn.isEnabled = false; joinIn.isEnabled = false }
        box.addView(nameIn)
        box.addView(onlineSw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        box.addView(hostSw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(serverIn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(roomIn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(joinIn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(relayIn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(tv("🎙 ตัดเสียงรบกวนไมค์ (เปลี่ยนได้ตอนใช้งานอยู่)", 13f, TEXT2, true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        val noiseGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("ปิด", "ปกติ", "แรง").forEachIndexed { i, t ->
            noiseGroup.addView(RadioButton(this).apply { text = t; id = 100 + i; setTextColor(Color.WHITE) })
        }
        noiseGroup.check(100 + prefs.getInt("noise", 1))
        noiseGroup.setOnCheckedChangeListener { _, id ->
            val lv = id - 100
            prefs.edit().putInt("noise", lv).apply()
            VoiceService.noiseLevel = lv
        }
        box.addView(noiseGroup)
        box.addView(tv("ปกติ = ตัดเสียงพัดลม/เสียงรอบข้างเบาๆ · แรง = ตัดเข้มขึ้น (ถ้าเสียงเราแหว่งให้ลดเป็นปกติ)", 11f, TEXT2),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        box.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        if (running) box.addView(tv("ตัดการเชื่อมต่อก่อน จึงจะแก้ค่าได้", 11f, AMBER),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        box.addView(btn("🛠 ดูบันทึกการทำงาน", PANEL2) { showLog() },
            LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(12) })
        AlertDialog.Builder(this)
            .setTitle("⚙ ตั้งค่า")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("บันทึก") { _, _ ->
                if (!running) {
                    val oldRoom = prefs.getString("room", "").orEmpty().ifEmpty { RelayLink.randomRoom() }
                    val roomTxt = roomIn.text.toString().trim()
                    val room = when {
                        roomTxt.isEmpty() -> oldRoom
                        RelayLink.isRoom(roomTxt) -> roomTxt
                        else -> { toast("รหัสห้องใช้ได้เฉพาะ a-z 0-9 _ - ยาว 4-32 ตัว"); oldRoom }
                    }
                    prefs.edit().putString("name", nameIn.text.toString().trim())
                        .putBoolean("host", hostSw.isChecked)
                        .putBoolean("online", onlineSw.isChecked)
                        .putString("server", serverIn.text.toString().trim())
                        .putString("room", room)
                        .putString("join", joinIn.text.toString().trim())
                        .putString("relay", relayIn.text.toString().trim()).apply()
                }
            }
            .setNegativeButton("ปิด", null)
            .show()
    }

    private fun showLog() {
        val t = tv(VoiceService.logs.joinToString("\n").ifEmpty { "(ยังไม่มีบันทึก)" }, 11f, TEXT2).apply {
            typeface = Typeface.MONOSPACE; setTextIsSelectable(true); setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        AlertDialog.Builder(this).setTitle("🛠 บันทึกการทำงาน")
            .setView(ScrollView(this).apply { addView(t) })
            .setPositiveButton("ปิด", null).show()
    }

    private fun versionName(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun showUpdates() {
        val t = tv("📱 แอป — ${versionName()}\n$APP_NOTES\n\n🧩 Mod\n$MOD_NOTES", 13f, Color.WHITE)
            .apply { setPadding(dp(20), dp(8), dp(20), dp(8)) }
        AlertDialog.Builder(this).setTitle("🆕 อัปเดตของ Mod และ App")
            .setView(ScrollView(this).apply { addView(t) })
            .setPositiveButton("รับทราบ", null).show()
    }

    private fun relayBase(): String = prefs.getString("relay", "").orEmpty().ifBlank { RelayLink.DEFAULT }

    /** ที่อยู่ ws(s):// ของห้องที่จะเข้า (โหมดออนไลน์) หรือ null ถ้าข้อมูลไม่พอ */
    private fun onlineTarget(): String? =
        if (prefs.getBoolean("host", true)) RelayLink.parse(relayBase(), prefs.getString("room", "").orEmpty())
        else RelayLink.parseJoin(prefs.getString("join", "").orEmpty(), relayBase())

    /** สิ่งที่โฮสต์ส่งให้เพื่อน: รหัสห้องสั้นๆ (ถ้าใช้รีเลย์กลางของแอป) หรือลิงก์เต็ม (ถ้าตั้งรีเลย์เอง) */
    private fun inviteShare(): String? {
        val room = prefs.getString("room", "").orEmpty()
        if (room.isEmpty()) return null
        if (prefs.getString("relay", "").orEmpty().isBlank()) return room
        return RelayLink.parse(relayBase(), room)?.let { RelayLink.toShare(it) }
    }

    /** บอกที่อยู่ให้เพื่อนใส่ + เตือนถ้าเครื่องใช้เน็ตมือถือ (เพื่อนต่อตรงไม่ได้) */
    private fun ipInfo(): String {
        val ok = mutableListOf<String>()
        var cell = false
        try {
            for (ni in java.net.NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                for (a in ni.inetAddresses.toList()) {
                    if (a !is java.net.Inet4Address) continue
                    val ip = a.hostAddress ?: continue
                    when {
                        n.startsWith("wlan") -> ok += "$ip:8080 (wifi)"
                        n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") -> ok += "$ip:8080 (ฮอตสปอตของคุณ)"
                        else -> cell = true
                    }
                }
            }
        } catch (e: Exception) { }
        return when {
            ok.isNotEmpty() -> "ให้เพื่อนใส่: " + ok.joinToString("   ")
            cell -> "⚠ เครื่องนี้ใช้เน็ตมือถือ เพื่อนต่อเข้ามาตรงๆ ไม่ได้\nเปิดฮอตสปอตแล้วให้เพื่อนต่อ wifi ของคุณ หรือทุกคนใช้ wifi วงเดียวกัน"
            else -> "(ยังไม่ได้ต่อเน็ต)"
        }
    }

    // ---------- สิทธิ์ + เริ่มบริการ ----------
    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) startVoice() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else toast("ต้องอนุญาตการใช้ไมโครโฟนก่อน")
    }

    private fun startVoice() {
        startForegroundService(Intent(this, VoiceService::class.java)
            .setAction(VoiceService.ACTION_START)
            .putExtra("name", prefs.getString("name", "").orEmpty().trim())
            .putExtra("host", prefs.getBoolean("host", true))
            .putExtra("online", prefs.getBoolean("online", false))
            .putExtra("room", "")
            .putExtra("server", if (prefs.getBoolean("online", false)) onlineTarget().orEmpty()
                                else prefs.getString("server", "").orEmpty().trim()))
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { super.onPause(); ui.removeCallbacksAndMessages(null) }

    // ---------- อัปเดตหน้าจอทุก 200ms ----------
    private fun refresh() {
        val running = VoiceService.running
        val conn = VoiceService.connected
        val st = VoiceService.status
        val muted = st?.muted ?: true
        val name = prefs.getString("name", "").orEmpty().trim()

        if (name != lastName) {
            lastName = name
            profileName.text = if (name.isEmpty()) "ยังไม่ได้ตั้งชื่อ" else name
            profileAvatar.bind(if (name.isEmpty()) "?" else name)
        }

        val on = running && conn && st != null && st.game && !muted
        val dotColor = when {
            !running || !conn -> RED
            st == null || !st.game -> AMBER
            muted -> RED
            else -> GREEN
        }
        dot.background = shape(dotColor, oval = true)
        profileStatus.text = when {
            !running -> "ยังไม่เชื่อมต่อ"
            !conn -> VoiceService.message
            st == null -> "…"
            !st.game -> "ไม่พบตัวละครคุณในเกม"
            !st.mc -> "เกมยังไม่เชื่อม"
            else -> "เชื่อมเกมแล้ว · ระยะ ${st.range} บล็อก"
        }
        connectBtn.text = if (running) "ตัดการเชื่อมต่อ" else "เชื่อมต่อเสียง"
        connectBtn.background = shape(if (running) PANEL2 else ACCENT, 10)

        micPixel.palette = if (on) Pixel.MIC_ON else Pixel.MIC_OFF
        micLabel.text = if (on) "🎤 ไมค์เปิดอยู่" else "🔇 ไมค์ปิดอยู่"
        micLabel.setTextColor(if (on) Color.parseColor("#8CFF9B") else Color.parseColor("#FF9A90"))
        meter.progress = if (on) ((VoiceService.client?.level ?: 0f) * 100).toInt() else 0
        val now = System.currentTimeMillis()
        if (now - addrAt > 3000) {
            addrAt = now
            val online = prefs.getBoolean("online", false)
            val isHost = prefs.getBoolean("host", true)
            addrLabel.text = when {
                isHost && online -> inviteShare()?.let { "รหัสห้องของคุณ: $it\n(แตะเพื่อคัดลอก ส่งให้เพื่อน)" }
                    ?: "ตั้งรหัสห้องในตั้งค่าก่อน"
                isHost -> ipInfo()
                else -> ""
            }
        }
        diagLabel.text = if (running && prefs.getBoolean("host", true)) {
            val lines = VoiceService.host?.diag().orEmpty().toMutableList()
            if (prefs.getBoolean("online", false)) lines.add("👥 ในห้องตอนนี้: ${st?.players?.size ?: 0} คน")
            lines.joinToString("\n")
        } else ""
        micToggle.text = if (on) "🎤 ไมค์เปิด" else "🔇 ไมค์ปิด"
        micToggle.background = shape(if (on) GREEN else RED, 10)

        val players = if (running) st?.players.orEmpty() else emptyList()
        val sig = players.joinToString("|") { "${it.name},${it.muted},${it.call}" }
        if (sig != lastSig) {
            lastSig = sig
            listTitle.text = "👥 ผู้เล่นในเซิร์ฟเวอร์ (${players.size})"
            rebuildList(players)
        }
        ui.postDelayed({ refresh() }, 200)
    }

    private fun rebuildList(players: List<VoiceClient.PlayerInfo>) {
        listBox.removeAllViews()
        if (players.isEmpty()) {
            listBox.addView(tv("ยังไม่มีผู้เล่น", 12f, TEXT2))
            return
        }
        for (p in players) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; background = shape(PANEL2, 10)
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            val av = AvatarView(this).apply { bind(p.name) }
            row.addView(av, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
            val nameCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            nameCol.addView(tv(p.name, 14f, Color.WHITE, true).apply { setSingleLine() })
            if (p.call.isNotEmpty()) nameCol.addView(tv("📞 ${p.call}", 10f, TEXT2))
            row.addView(nameCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv(if (p.muted) "🔇" else "🎤", 16f, Color.WHITE))
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }
    }
}
