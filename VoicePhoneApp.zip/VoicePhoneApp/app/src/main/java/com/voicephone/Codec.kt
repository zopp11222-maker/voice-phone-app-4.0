package com.voicephone

import java.security.SecureRandom

/**
 * ย่อเสียงให้เบาพอสำหรับเน็ตมือถือ: 16 kHz PCM16 -> 8 kHz μ-law (8 บิต)
 * เหลือราว 8 KB/วินาที ต่อคนที่กำลังพูด (เดิม 32 KB/วินาที)
 */
object Codec {
    private const val BIAS = 0x84
    private const val CLIP = 32635

    fun encodeSample(s: Short): Byte {
        var x = s.toInt()
        val sign = if (x < 0) { x = -x; 0x80 } else 0
        if (x > CLIP) x = CLIP
        x += BIAS
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (x and mask) == 0) { exp--; mask = mask shr 1 }
        val mant = (x shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or mant).inv().toByte()
    }

    fun decodeSample(b: Byte): Short {
        val u = b.toInt().inv() and 0xFF
        val sign = u and 0x80
        val exp = (u shr 4) and 0x07
        val mant = u and 0x0F
        val v = (((mant shl 3) + BIAS) shl exp) - BIAS
        return (if (sign != 0) -v else v).toShort()
    }

    /** 16 kHz PCM16 (n ตัวอย่าง) -> μ-law 8 kHz (เฉลี่ยทีละ 2 ตัวอย่าง) */
    fun encode(pcm: ShortArray, n: Int): ByteArray {
        val out = ByteArray(n / 2)
        for (i in 0 until n / 2) {
            val a = pcm[2 * i].toInt()
            val b = pcm[2 * i + 1].toInt()
            out[i] = encodeSample(((a + b) / 2).toShort())
        }
        return out
    }

    /** μ-law 8 kHz -> PCM16 16 kHz (เติมค่าตรงกลางระหว่างตัวอย่าง) */
    fun decode(data: ByteArray, off: Int, len: Int): ShortArray {
        val out = ShortArray(len * 2)
        for (i in 0 until len) {
            val cur = decodeSample(data[off + i]).toInt()
            val next = if (i + 1 < len) decodeSample(data[off + i + 1]).toInt() else cur
            out[2 * i] = cur.toShort()
            out[2 * i + 1] = ((cur + next) / 2).toShort()
        }
        return out
    }
}

/** จัดการลิงก์ห้องออนไลน์ เช่น https://my-relay.onrender.com/ab12cd34 */
object RelayLink {
    private val roomRe = Regex("[A-Za-z0-9_-]{4,32}")

    /** แปลงสิ่งที่ผู้ใช้พิมพ์เป็น ws(s)://host/ห้อง หรือ null ถ้าข้อมูลไม่พอ */
    fun parse(input: String, defaultRoom: String): String? {
        var s = input.trim()
        if (s.isEmpty()) return null
        s = when {
            s.startsWith("https://") -> "wss://" + s.removePrefix("https://")
            s.startsWith("http://") -> "ws://" + s.removePrefix("http://")
            s.startsWith("wss://") || s.startsWith("ws://") -> s
            else -> "wss://$s"
        }
        val scheme = s.substringBefore("://")
        val rest = s.substringAfter("://")
        val host = rest.substringBefore('/')
        val path = rest.substringAfter('/', "").trim('/').substringBefore('/')
        val room = path.ifEmpty { defaultRoom }
        if (host.isEmpty() || !roomRe.matches(room)) return null
        return "$scheme://$host/$room"
    }

    fun toShare(wsUrl: String): String =
        wsUrl.replaceFirst("wss://", "https://").replaceFirst("ws://", "http://")

    fun randomRoom(): String {
        val ch = "abcdefghjkmnpqrstuvwxyz23456789"
        val r = SecureRandom()
        return (1..8).map { ch[r.nextInt(ch.length)] }.joinToString("")
    }
}
