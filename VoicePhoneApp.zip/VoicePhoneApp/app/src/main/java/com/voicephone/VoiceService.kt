package com.voicephone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log

/** Foreground Service (ประเภท microphone) ให้ไมค์ทำงานต่อเบื้องหลังตอนเล่น Minecraft */
class VoiceService : Service() {
    companion object {
        const val ACTION_START = "com.voicephone.START"
        const val ACTION_STOP = "com.voicephone.STOP"
        const val ACTION_TOGGLE = "com.voicephone.TOGGLE"
        private const val CHANNEL = "voice"

        @Volatile var running = false
        @Volatile var connected = false
        @Volatile var message = ""
        @Volatile var status: VoiceClient.Status? = null
        @Volatile var client: VoiceClient? = null
        @Volatile var host: HostServer? = null
        val logs = java.util.concurrent.CopyOnWriteArrayList<String>()

        fun addLog(s: String) {
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logs.add("$t $s")
            while (logs.size > 40) logs.removeAt(0)
            Log.i("VoicePhone", s)
        }
    }

    private var wake: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var name = ""
    private var url = ""
    private var failHint = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_TOGGLE -> { client?.toggleMute(); updateNotif() }
            ACTION_STOP -> stopAll()
            else -> if (!running) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        // ต้องเรียก startForeground ก่อนเสมอ (ภายใน 5 วินาทีหลัง startForegroundService)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW))
        val n = buildNotif("กำลังเชื่อมต่อ…")
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        name = intent.getStringExtra("name").orEmpty()
        val isHost = intent.getBooleanExtra("host", false)
        val online = intent.getBooleanExtra("online", false)
        val server = intent.getStringExtra("server").orEmpty()
        if (name.isEmpty()) { stopAll(); return }
        if (online) {
            val u = RelayLink.parse(server, intent.getStringExtra("room").orEmpty())
            if (u == null) { addLog("ลิงก์รีเลย์/รหัสห้องไม่ถูกต้อง: $server"); stopAll(); return }
            url = u
            failHint = "ต่อรีเลย์ไม่ติด — เช็กลิงก์ห้อง และรอสักครู่ถ้าเซิร์ฟเวอร์เพิ่งตื่น (อาจนานราว 1 นาที)"
        } else {
            url = "ws://" + (if (isHost) "127.0.0.1:8080" else server.ifEmpty { "127.0.0.1:8080" })
            failHint = "ต่อโฮสต์ไม่ติด — เช็กว่าอยู่ wifi/ฮอตสปอตเดียวกับโฮสต์ และ IP:พอร์ตถูกต้อง"
        }

        cleanup()
        addLog("เริ่มบริการ host=$isHost online=$online url=$url")
        running = true; connected = false; status = null
        message = if (online) "กำลังเชื่อมต่อรีเลย์… (ครั้งแรกอาจนานราว 1 นาที)" else "กำลังเชื่อมต่อ…"
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicephone:mic").also { it.acquire() }

        if (isHost) host = HostServer(if (online) url else null) { addLog(it) }.also { it.start() }
        h.postDelayed({ connectClient() }, if (isHost && !online) 800 else 0)
    }

    private fun connectClient() {
        if (!running) return
        addLog("กำลังเชื่อมเสียงไปที่ $url")
        val c = VoiceClient(url, name, failHint,
            onStatus = { s -> status = s; connected = true; message = ""; h.post { updateNotif() } },
            onClosed = { why ->
                addLog("เสียงหลุด: $why")
                connected = false; status = null; message = "หลุดการเชื่อมต่อ ($why) กำลังลองใหม่…"
                h.post { updateNotif(); h.postDelayed({ connectClient() }, 2000) }
            })
        client = c
        c.start()
    }

    private fun buildNotif(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val tog = PendingIntent.getService(this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_TOGGLE), flags)
        val stop = PendingIntent.getService(this, 2,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP), flags)
        val icon = Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "เปิด/ปิดไมค์", tog).build())
            .addAction(Notification.Action.Builder(icon, "ตัดการเชื่อมต่อ", stop).build())
            .build()
    }

    private fun updateNotif() {
        if (!running) return
        val s = status
        val text = when {
            !connected -> message
            s == null || !s.game -> "🟡 เชื่อมต่อแล้ว (ยังไม่พบตัวละครในเกม)"
            s.muted -> "🔴 ปิดไมค์อยู่"
            else -> "🟢 เปิดไมค์อยู่"
        }
        getSystemService(NotificationManager::class.java).notify(1, buildNotif(text))
    }

    private fun cleanup() {
        running = false
        h.removeCallbacksAndMessages(null)
        client?.stop(); client = null
        host?.stop(); host = null
        try { wake?.release() } catch (e: Exception) { }
        wake = null
        connected = false; status = null
    }

    private fun stopAll() {
        cleanup()
        message = ""
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}
