plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.voicephone"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.voicephone"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "Beta 2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
dependencies {
    implementation("org.java-websocket:Java-WebSocket:1.5.6")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
